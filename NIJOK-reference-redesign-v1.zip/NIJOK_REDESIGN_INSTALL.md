# NIJOK Reference Redesign

This redesign is additive: it keeps the existing NIJOK game engine and adds a new visual landing page.

## 1. Upload these two files
- `nijok-redesign.css`
- `nijok-redesign.js`

to the root of the GitHub repository.

## 2. Add the CSS inside `<head>` of `index.html`

```html
<link rel="stylesheet" href="nijok-redesign.css">
```

Put it AFTER the existing stylesheet/style blocks.

## 3. Add the JS before `</body>`

```html
<script src="nijok-redesign.js"></script>
```

Put it AFTER the existing NIJOK JavaScript.

## 4. Push/commit to GitHub Pages

The redesign will automatically:
- replace the old hero with the reference-style “Play. Learn. Discover Food.” hero
- add the 5-feature strip
- restyle the existing 4 game modes
- add a Today's Challenge banner
- keep `openGame('guess')`, `openGame('quiz')`, `openGame('pair')`, and `openGame('time')`
- preserve the existing dashboard, daily fact, profile and leaderboard
- remain responsive on mobile

The current repository contains the existing game engine and the four-game playground, so the patch deliberately does not delete that functionality.
