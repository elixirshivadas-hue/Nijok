
/* =========================================================
   NIJOK — Reference Redesign JS
   This is an additive patch: it keeps the existing NIJOK
   game engine and rewires only the visible landing-page UI.
   ========================================================= */

(function(){

  function ready(fn){
    if(document.readyState === "loading"){
      document.addEventListener("DOMContentLoaded", fn, {once:true});
    }else{
      fn();
    }
  }

  function make(tag, cls, html){
    const el = document.createElement(tag);
    if(cls) el.className = cls;
    if(html !== undefined) el.innerHTML = html;
    return el;
  }

  function buildReferenceHero(){
    const oldHero = document.querySelector(".hero");
    if(!oldHero || document.getElementById("nijok-reference-hero")) return;

    const hero = make("section");
    hero.id = "nijok-reference-hero";
    hero.innerHTML = `
      <span class="nijok-deco-leaf a"></span>
      <span class="nijok-deco-leaf b"></span>
      <span class="nijok-deco-leaf c"></span>

      <div class="nijok-hero-inner">
        <div>
          <div class="nijok-hero-kicker">Food Knowledge Game</div>

          <h1 class="nijok-hero-title">
            Play. Learn.<br>
            <em>Discover Food.</em>
          </h1>

          <p class="nijok-hero-copy">
            Test your knowledge, explore new cultures and
            unlock the stories behind every dish.
            NIJOK makes learning about food fun,
            interactive and rewarding.
          </p>

          <div class="nijok-hero-actions">
            <button class="nijok-ref-btn primary"
                    onclick="document.getElementById('play')?.scrollIntoView({behavior:'smooth'})">
              🌿 Start Playing&nbsp; →
            </button>

            <button class="nijok-ref-btn secondary"
                    onclick="document.getElementById('learn')?.scrollIntoView({behavior:'smooth'})">
              How It Works&nbsp; ◉
            </button>
          </div>
        </div>

        <div class="nijok-hero-visual" aria-label="Food and culture collage">
          <div class="nijok-leaf-bg"></div>

          <div class="nijok-food-collage">
            <div class="nijok-food-photo one">
              <img src="https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=700&q=85" alt="Fresh food">
            </div>
            <div class="nijok-food-photo two">
              <img src="https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=800&q=85" alt="Food spread">
            </div>
            <div class="nijok-food-photo three">
              <img src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=85" alt="Food culture">
            </div>
            <div class="nijok-food-photo four">
              <img src="https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=800&q=85" alt="Pizza">
            </div>
          </div>

          <div class="nijok-hero-story">
            Every Food<br>
            Has a Story
          </div>
        </div>
      </div>
    `;

    oldHero.replaceWith(hero);
  }

  function buildFeatureStrip(){
    if(document.getElementById("nijok-reference-features")) return;

    const hero = document.getElementById("nijok-reference-hero");
    if(!hero) return;

    const strip = make("section");
    strip.id = "nijok-reference-features";

    const features = [
      ["🧠","Fun & Engaging","Learn through interactive quizzes."],
      ["🌎","Global & Local","Explore food from everywhere."],
      ["📖","Build Knowledge","History, culture, ingredients."],
      ["🏆","Earn Rewards","Collect points and badges."],
      ["👥","Compete & Share","Challenge friends and climb."]
    ];

    strip.innerHTML = features.map(x => `
      <div class="nijok-feature">
        <div class="nijok-feature-icon">${x[0]}</div>
        <strong>${x[1]}</strong>
        <span>${x[2]}</span>
      </div>
    `).join("");

    hero.after(strip);
  }

  function retitleGameSection(){
    const heading = document.querySelector(".playground-heading");
    if(!heading) return;

    const h2 = heading.querySelector("h2");
    const p = heading.querySelector("p");

    if(h2){
      h2.innerHTML = `Choose Your <span>Challenge</span>`;
    }

    if(p){
      p.textContent =
        "Different ways to play. Same goal — become a curious Food Explorer.";
    }
  }

  function addDailyChallenge(){
    if(document.getElementById("nijok-reference-daily")) return;

    const play = document.getElementById("play");
    if(!play) return;

    const section = make("section");
    section.id = "nijok-reference-daily";
    section.innerHTML = `
      <div class="nijok-daily-inner">
        <div class="nijok-daily-copy">
          <span>🌿 TODAY'S CHALLENGE</span>
          <h2>How much do you know about food?</h2>
          <p>
            Take today's quick food quiz, earn points and
            keep your learning streak alive.
          </p>
          <button onclick="openGame('quiz')">
            Start Today's Challenge →
          </button>
        </div>

        <div class="nijok-daily-art">
          <div>Think.<br>Explore.<br>Learn.</div>
          <span>🌿</span>
        </div>
      </div>
    `;

    play.after(section);
  }

  function addReferenceFooter(){
    if(document.getElementById("nijok-reference-footer")) return;

    const footer = document.querySelector("footer");
    if(!footer) return;

    footer.id = "nijok-reference-footer";
  }

  function init(){
    document.body.classList.add("nijok-reference");

    const topBar = document.querySelector(".top-bar");
    if(topBar) topBar.style.display = "none";

    buildReferenceHero();
    buildFeatureStrip();

    // Existing NIJOK sections are generated by the original JS.
    // Give them a moment to appear, then restyle/retitle them.
    retitleGameSection();
    addDailyChallenge();
    addReferenceFooter();

    setTimeout(function(){
      retitleGameSection();
      addDailyChallenge();
      addReferenceFooter();
    }, 1200);
  }

  ready(init);

})();
